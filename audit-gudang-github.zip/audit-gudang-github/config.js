// Isi dengan URL Web App Apps Script (yang berakhiran /exec)
window.APP_CONFIG = {
  API_URL: "GANTI_DENGAN_URL_WEB_APP_APPS_SCRIPT/exec",
  API_KEY: "" // opsional, harus sama dengan Script Property API_KEY di Apps Script
};
