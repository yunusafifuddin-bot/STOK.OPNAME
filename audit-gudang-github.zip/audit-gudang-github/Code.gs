/** AUDIT HARIAN GUDANG v3 - Code.gs (API untuk GitHub Pages: cache + baca sheet minimal) **/
const HEAD = {
  Barang: ['Kode','Nama Barang','Kategori','Satuan','Lokasi','Stok Sistem'],
  Audit: ['ID','Tanggal','Kode','Nama Barang','Stok Sistem','Stok Fisik','Selisih','Auditor','Catatan','Waktu Input'],
  StokPerusahaan: ['Kode','Nama Barang','Stok Terkini Perusahaan','Update Terakhir']
};
const TZ = Session.getScriptTimeZone();
const VER = '3';

/* ---------- API (dipanggil dari GitHub Pages) ---------- */
// Fungsi yang boleh dipanggil dari luar
const API_FN = {
  getDashboard: getDashboard, getBarang: getBarang, saveBarang: saveBarang, deleteBarang: deleteBarang,
  getAuditForm: getAuditForm, saveAudit: saveAudit, getSelisih: getSelisih, getGap: getGap,
  getBelumAudit: getBelumAudit, getRekon: getRekon, saveStokPerusahaan: saveStokPerusahaan
};

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  getSS_();
  return json_({ ok: true, app: 'Audit Harian Gudang', ver: VER });
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    const key = PropertiesService.getScriptProperties().getProperty('API_KEY');
    if (key && req.key !== key) throw new Error('API key salah');
    const fn = API_FN[req.fn];
    if (!fn) throw new Error('Fungsi tidak dikenal: ' + req.fn);
    getSS_();
    return json_({ ok: true, data: fn.apply(null, req.args || []) });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Audit Gudang')
    .addItem('Setup Spreadsheet Otomatis', 'setupSpreadsheet').addToUi();
}

/** Jalankan manual dari editor / menu untuk setup (ulang) */
function setupSpreadsheet() {
  PropertiesService.getScriptProperties().deleteProperty('READY');
  _ss = null;
  const ss = getSS_();
  Logger.log('Spreadsheet siap: ' + ss.getUrl());
  return ss.getUrl();
}

/* ---------- SPREADSHEET & CACHE (inti kecepatan) ---------- */
let _ss = null; const _mem = {};

function getSS_() {
  if (_ss) return _ss;
  const p = PropertiesService.getScriptProperties();
  try { _ss = SpreadsheetApp.getActiveSpreadsheet(); } catch (e) {}
  if (!_ss) {
    const id = p.getProperty('SSID');
    if (id) { try { _ss = SpreadsheetApp.openById(id); } catch (e) {} }
  }
  if (!_ss) {
    _ss = SpreadsheetApp.create('Database Audit Gudang');
    p.setProperty('SSID', _ss.getId());
  }
  if (p.getProperty('READY') !== VER) { migrate_(_ss); setup_(_ss); p.setProperty('READY', VER); }
  return _ss;
}

function cget_(k) {
  if (_mem[k]) return _mem[k];
  const c = CacheService.getScriptCache(), n = Number(c.get(k + ':n'));
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(k + ':' + i);
  const m = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (m[k + ':' + i] == null) return null; s += m[k + ':' + i]; }
  return (_mem[k] = JSON.parse(s));
}
function cput_(k, v) {
  _mem[k] = v;
  const s = JSON.stringify(v), parts = [];
  for (let i = 0; i < s.length; i += 30000) parts.push(s.slice(i, i + 30000));
  if (parts.length > 60) return;
  const o = {}; parts.forEach((x, i) => o[k + ':' + i] = x); o[k + ':n'] = String(parts.length);
  try { CacheService.getScriptCache().putAll(o, 21600); } catch (e) {}
}
function cdel_(k) { delete _mem[k]; CacheService.getScriptCache().remove(k + ':n'); }

/** Hapus kolom harga/nilai versi lama (data lain aman) */
function migrate_(ss) {
  const b = ss.getSheetByName('Barang'), a = ss.getSheetByName('Audit');
  if (b && b.getRange('G1').getValue() === 'Harga Satuan') b.deleteColumn(7);
  if (a && a.getRange('H1').getValue() === 'Nilai Selisih') a.deleteColumn(8);
}

function setup_(ss) {
  Object.keys(HEAD).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const h = HEAD[name];
    sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold')
      .setBackground('#1e40af').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    sh.autoResizeColumns(1, h.length);
  });
  ss.getSheetByName('Barang').getRange('A:A').setNumberFormat('@');
  ss.getSheetByName('Audit').getRange('B:C').setNumberFormat('@');
  ss.getSheetByName('StokPerusahaan').getRange('A:A').setNumberFormat('@');
  const b = ss.getSheetByName('Barang');
  if (b.getLastRow() < 2) {
    const s = [
      ['BRG-001','Beras Premium 5kg','Sembako','Karung','Rak A1',120],
      ['BRG-002','Minyak Goreng 2L','Sembako','Botol','Rak A2',200],
      ['BRG-003','Gula Pasir 1kg','Sembako','Pack','Rak A3',150],
      ['BRG-004','Mie Instan Karton','Makanan','Karton','Rak B1',80],
      ['BRG-005','Sabun Cuci 800ml','Rumah Tangga','Botol','Rak C1',95],
      ['BRG-006','Detergen 1kg','Rumah Tangga','Pack','Rak C2',110],
      ['BRG-007','Air Mineral 600ml Dus','Minuman','Dus','Rak D1',300],
      ['BRG-008','Kopi Sachet Renteng','Minuman','Renteng','Rak D2',160]
    ];
    b.getRange(2, 1, s.length, 6).setValues(s);
  }
  const d = ss.getSheetByName('Sheet1');
  if (d && ss.getSheets().length > 2 && d.getLastRow() === 0) ss.deleteSheet(d);
  cdel_('B'); cdel_('A');
}

function readRows_(name, cols) {
  const sh = getSS_().getSheetByName(name), n = sh.getLastRow();
  if (n < 2) return [];
  return sh.getRange(2, 1, n - 1, cols).getValues().filter(r => r[0] !== '' || r[2] !== '');
}
const ds_ = v => v instanceof Date ? Utilities.formatDate(v, TZ, 'yyyy-MM-dd') : String(v);
const barangObj_ = r => ({ kode: String(r[0]), nama: r[1], kategori: r[2], satuan: r[3], lokasi: r[4], stok: Number(r[5]) || 0 });
const auditObj_ = r => ({ id: r[0], tanggal: ds_(r[1]), kode: String(r[2]), nama: r[3], sistem: Number(r[4]), fisik: Number(r[5]), selisih: Number(r[6]), auditor: r[7], catatan: r[8] });
const today_ = () => Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');

function getBarang() {
  let b = cget_('B'); if (b) return b;
  b = readRows_('Barang', 6).map(barangObj_); cput_('B', b); return b;
}
function auditAll_() {
  let a = cget_('A'); if (a) return a;
  a = readRows_('Audit', 9).map(auditObj_); cput_('A', a); return a;
}

/* ---------- BARANG ---------- */
function saveBarang(o, oldKode) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const sh = getSS_().getSheetByName('Barang');
    const kode = String(o.kode).trim();
    if (!kode || !String(o.nama).trim()) throw new Error('Kode dan nama wajib diisi');
    const kodes = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues() : [];
    let idx = -1, dup = false;
    kodes.forEach((r, i) => {
      if (oldKode && String(r[0]) === oldKode) idx = i + 2;
      if (String(r[0]) === kode && kode !== oldKode) dup = true;
    });
    if (dup) throw new Error('Kode barang sudah ada');
    const row = [kode, o.nama, o.kategori, o.satuan, o.lokasi, Number(o.stok) || 0];
    if (idx > 0) sh.getRange(idx, 1, 1, 6).setValues([row]); else sh.appendRow(row);
    cdel_('B');
    return getBarang();
  } finally { lock.releaseLock(); }
}

function deleteBarang(kode) {
  const sh = getSS_().getSheetByName('Barang');
  const n = sh.getLastRow();
  if (n > 1) {
    const k = sh.getRange(2, 1, n - 1, 1).getValues();
    for (let i = k.length - 1; i >= 0; i--) if (String(k[i][0]) === kode) sh.deleteRow(i + 2);
  }
  cdel_('B');
  return getBarang();
}

/* ---------- AUDIT ---------- */
function getAuditForm(tanggal) {
  const audit = {};
  auditAll_().forEach(a => { if (a.tanggal === tanggal) audit[a.kode] = a; });
  return { barang: getBarang(), audit: audit };
}

/** p = {tanggal, auditor, adjust, items:[{kode, fisik, catatan}]} - hanya barang yang dipilih */
function saveAudit(p) {
  const lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    const ss = getSS_(), sa = ss.getSheetByName('Audit'), sb = ss.getSheetByName('Barang');
    const bmap = {};
    getBarang().forEach((b, i) => bmap[b.kode] = { r: i + 2, d: b });
    // hapus audit lama pada tanggal & kode yang sama (hindari duplikat)
    const keys = {}; p.items.forEach(i => keys[i.kode] = 1);
    const n = sa.getLastRow();
    if (n > 1) {
      const bc = sa.getRange(2, 2, n - 1, 2).getValues();
      for (let i = bc.length - 1; i >= 0; i--)
        if (ds_(bc[i][0]) === p.tanggal && keys[String(bc[i][1])]) sa.deleteRow(i + 2);
    }
    const now = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss');
    const out = [];
    p.items.forEach((it, k) => {
      const b = bmap[it.kode]; if (!b) return;
      const fisik = Number(it.fisik), sel = fisik - b.d.stok;
      out.push(['AUD-' + Date.now() + '-' + k, p.tanggal, it.kode, b.d.nama, b.d.stok, fisik, sel, p.auditor || '', it.catatan || '', now]);
      if (p.adjust) sb.getRange(b.r, 6).setValue(fisik);
    });
    if (out.length) sa.getRange(sa.getLastRow() + 1, 1, out.length, 10).setValues(out);
    cdel_('A'); if (p.adjust) cdel_('B');
    return out.length;
  } finally { lock.releaseLock(); }
}

/* ---------- SELISIH & GAP ---------- */
function getSelisih(dari, sampai) {
  return auditAll_().filter(a => a.tanggal >= dari && a.tanggal <= sampai && a.selisih !== 0)
    .sort((x, y) => y.tanggal.localeCompare(x.tanggal));
}

function gap_(all) {
  const per = {}, hari = {};
  const t = { kurang: 0, lebih: 0, net: 0, diaudit: all.length, bermasalah: 0 };
  all.forEach(a => {
    const p = per[a.kode] || (per[a.kode] = { kode: a.kode, nama: a.nama, kurang: 0, lebih: 0, net: 0, abs: 0, kali: 0 });
    const h = hari[a.tanggal] || (hari[a.tanggal] = { tanggal: a.tanggal, item: 0, bermasalah: 0, net: 0 });
    if (a.selisih < 0) { p.kurang += a.selisih; t.kurang += a.selisih; } else { p.lebih += a.selisih; t.lebih += a.selisih; }
    p.net += a.selisih; p.abs += Math.abs(a.selisih); t.net += a.selisih;
    h.item++; h.net += a.selisih;
    if (a.selisih !== 0) { p.kali++; h.bermasalah++; t.bermasalah++; }
  });
  const items = Object.keys(per).map(k => per[k]).filter(x => x.kali > 0).sort((a, b) => b.abs - a.abs);
  return { total: t, items: items, hari: Object.keys(hari).sort().map(k => hari[k]) };
}
function getGap(dari, sampai) {
  return gap_(auditAll_().filter(a => a.tanggal >= dari && a.tanggal <= sampai));
}

/* ---------- BELUM DIAUDIT PER BULAN ---------- */
/** bulan = 'yyyy-MM' */
function getBelumAudit(bulan) {
  const brg = getBarang(), done = {}, last = {};
  auditAll_().forEach(a => {
    if (a.tanggal.slice(0, 7) === bulan) done[a.kode] = 1;
    if (!last[a.kode] || a.tanggal > last[a.kode]) last[a.kode] = a.tanggal;
  });
  const belum = brg.filter(b => !done[b.kode])
    .map(b => ({ kode: b.kode, nama: b.nama, kategori: b.kategori, lokasi: b.lokasi, last: last[b.kode] || '' }));
  return { total: brg.length, sudah: brg.length - belum.length, belum: belum };
}

/* ---------- DASHBOARD ---------- */
function getDashboard() {
  const brg = getBarang(), aud = auditAll_(), td = today_();
  const d7 = new Date(); d7.setDate(d7.getDate() - 6);
  const k7 = Utilities.formatDate(d7, TZ, 'yyyy-MM-dd');
  const hariIni = aud.filter(a => a.tanggal === td);
  const gap = gap_(aud.filter(a => a.tanggal >= k7 && a.tanggal <= td));
  const trend = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const k = Utilities.formatDate(d, TZ, 'yyyy-MM-dd');
    const h = gap.hari.filter(x => x.tanggal === k)[0];
    trend.push({ tanggal: k, bermasalah: h ? h.bermasalah : 0 });
  }
  const bln = td.slice(0, 7), done = {};
  aud.forEach(a => { if (a.tanggal.slice(0, 7) === bln) done[a.kode] = 1; });
  const sudahBulan = brg.filter(b => done[b.kode]).length;
  return {
    totalItem: brg.length,
    sudahAudit: hariIni.length,
    selisihHariIni: hariIni.filter(a => a.selisih !== 0).length,
    gapHariIni: hariIni.reduce((s, a) => s + a.selisih, 0),
    belumBulan: brg.length - sudahBulan,
    gap7: gap.total, trend: trend, top: gap.items.slice(0, 5)
  };
}

/* ---------- STOK APLIKASI vs STOK PERUSAHAAN ---------- */
function getRekon() {
  const ps = {};
  readRows_('StokPerusahaan', 4).forEach(r => ps[String(r[0])] = { v: r[2] === '' ? null : Number(r[2]), u: String(r[3]) });
  return {
    list: getBarang().map(b => ({ kode: b.kode, nama: b.nama, satuan: b.satuan, app: b.stok,
      per: ps[b.kode] ? ps[b.kode].v : null, update: ps[b.kode] ? ps[b.kode].u : '' }))
  };
}

/** items = [{kode, stok}] - dari input manual / upload CSV template */
function saveStokPerusahaan(items) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const sh = getSS_().getSheetByName('StokPerusahaan'), now = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss');
    const cur = {}; readRows_('StokPerusahaan', 4).forEach(r => cur[String(r[0])] = { v: r[2], u: r[3] });
    let n = 0;
    items.forEach(it => {
      const v = String(it.stok).trim();
      if (v === '' || isNaN(Number(v))) return;
      cur[String(it.kode).trim()] = { v: Number(v), u: now }; n++;
    });
    const out = getBarang().map(b => [b.kode, b.nama, cur[b.kode] ? cur[b.kode].v : '', cur[b.kode] ? cur[b.kode].u : '']);
    if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, 4).clearContent();
    if (out.length) sh.getRange(2, 1, out.length, 4).setValues(out);
    return n;
  } finally { lock.releaseLock(); }
}
