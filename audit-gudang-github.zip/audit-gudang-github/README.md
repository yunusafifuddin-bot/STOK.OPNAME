# Audit Harian Gudang — GitHub Pages + Apps Script

Tampilan (index.html) di-host di GitHub Pages, data tetap di Google Sheets lewat Apps Script.
Setiap `git push` ke branch `main` otomatis dirilis oleh GitHub Actions.

## A. Apps Script (backend)
1. Buka script lama Anda → ganti isi `Code.gs` dengan file `Code.gs` di folder ini.
2. Hapus file `index` (HTML) dari proyek Apps Script (tidak dipakai lagi).
3. (Opsional, disarankan) Project Settings → Script Properties → tambah `API_KEY` = kata sandi bebas.
4. Deploy → New deployment → Web app: Execute as **Me**, Who has access **Anyone** → Deploy.
5. Salin URL yang berakhiran `/exec`.

## B. GitHub (frontend + rilis otomatis)
1. Buat repository baru, upload semua isi folder ini (termasuk folder `.github`).
2. Settings → Pages → Source: **GitHub Actions**.
3. Settings → Secrets and variables → Actions → tab **Variables** → New repository variable:
   - `API_URL` = URL `/exec` tadi
   - `API_KEY` = sama dengan Script Property (kosongkan jika tidak dipakai)
   (Alternatif: edit `config.js` langsung.)
4. Tab Actions → jalankan "Deploy ke GitHub Pages" (atau push apa saja ke `main`).
5. Alamat aplikasi: `https://<username>.github.io/<nama-repo>/`

## Update berikutnya
Ubah file → commit/push ke `main` → otomatis rilis ulang dalam ±1 menit.
Jika Code.gs diubah: Deploy → Manage deployments → Edit → New version.

## Catatan
- Repo publik berarti `API_URL` dan `API_KEY` bisa dilihat orang. Gunakan repo privat (butuh GitHub Pro/Team untuk Pages privat) atau terima risiko ini; API_KEY hanya pagar sederhana.
- Di HP: Chrome ⋮ → Tambahkan ke layar utama untuk tampilan layar penuh.
